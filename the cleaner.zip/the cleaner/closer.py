import psutil, win32gui, win32process, time, os

MAX_ALLOWED_PROCESSES = 56
my_pid = os.getpid()  # ← Получаем PID текущего скрипта

whitelist = {
    "system", "idle", "explorer", "winlogon", "csrss", "services", "lsass",
    "smss", "svchost", "dwm", "audiodg", "spoolsv", "python", "python3", "conhost",
    "searchindexer", "startmenuexperiencehost", "securityhealthservice",
    "sihost", "fontdrvhost", "runtimebroker", "ctfmon",
    "chrome", "msedge", "firefox", "opera", "brave"
}

def has_visible_window(pid):
    hwnds = []
    def callback(hwnd, _):
        try:
            _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
            if found_pid == pid and win32gui.IsWindowVisible(hwnd):
                hwnds.append(hwnd)
        except: pass
        return True
    win32gui.EnumWindows(callback, None)
    return len(hwnds) > 0

def load_kill_list():
    if not os.path.exists("list.txt"): return []
    with open("list.txt", "r", encoding="utf-8") as f:
        return [line.strip().lower() for line in f if line.strip()]

kill_keywords = load_kill_list()
all_procs = list(psutil.process_iter(['pid', 'name', 'username']))
background = []
for p in all_procs:
    try:
        if not p.is_running(): continue
        if p.pid == my_pid: continue  # ← НЕ трогаем сам скрипт
        name = p.info['name'].lower().replace(".exe", "")
        user = (p.info['username'] or "").lower()
        if name in whitelist: continue
        if has_visible_window(p.pid): continue
        if "system" in user or "service" in user: continue
        if any(keyword in name for keyword in kill_keywords):
            print(f"⛔ Из list.txt: закрываю {name} (PID {p.pid})")
            p.terminate(); time.sleep(0.05); continue
        background.append(p)
    except: continue

print(f"🔍 Фоновых процессов без GUI: {len(background)}")
if len(background) <= MAX_ALLOWED_PROCESSES:
    print("✅ Лимит не превышен.")
else:
    to_kill = len(background) - MAX_ALLOWED_PROCESSES
    print(f"⚠️ Превышено на {to_kill} — начинаю очистку...")
    killed = 0
    for proc in background:
        try:
            if proc.pid == my_pid: continue  # ← Ещё раз на всякий случай
            print(f"⛔ Закрываю: {proc.info['name']} (PID {proc.pid})")
            proc.terminate(); killed += 1
            time.sleep(0.05)
            if killed >= to_kill: break
        except: continue
    print(f"✅ Завершено: {killed}")
