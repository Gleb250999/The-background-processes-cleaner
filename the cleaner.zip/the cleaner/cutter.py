import psutil

# Белый список: оставляем эти процессы
whitelist = {
    "system", "idle", "explorer", "winlogon", "csrss",
    "services", "lsass", "smss", "svchost", "dwm",
    "audiodg", "spoolsv", "python", "python3", "conhost",
    "searchindexer", "startmenuexperiencehost", "securityhealthservice",
    "sihost", "fontdrvhost", "runtimebroker", "ctfmon"
}

print("📋 Проверка всех процессов...")

found = False
for proc in psutil.process_iter(['pid', 'name']):
    try:
        name = proc.info['name'].lower().replace('.exe', '')
        pid = proc.info['pid']

        if name not in whitelist:
            found = True
            print(f"⛔ Завершаю: {name} (PID {pid})")
            proc.terminate()

    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue

if not found:
    print("✅ Все фоновые процессы в норме (только разрешённые)")
else:
    print("✅ Завершение ненужных процессов выполнено.")
