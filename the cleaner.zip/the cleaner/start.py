import os
import sys
import subprocess
import time

def add_to_startup():
    script_path = os.path.abspath(sys.argv[0])
    startup_folder = os.path.join(os.getenv('APPDATA'), r'Microsoft\Windows\Start Menu\Programs\Startup')
    bat_path = os.path.join(startup_folder, 'start_my_script.bat')

    if not os.path.exists(bat_path):
        with open(bat_path, 'w') as bat_file:
            # Важно: использовать двойные кавычки и pythonw для тихого запуска
            bat_file.write(f'start "" python "{script_path}"\n')
        print("Скрипт добавлен в автозагрузку.")
    else:
        print("Скрипт уже в автозагрузке.")

def main():
    time.sleep(10)  # Ждать, пока ОС полностью загрузится

    script_dir = os.path.dirname(os.path.abspath(__file__))  # Папка, где находится main.py

    closer_path = os.path.join(script_dir, 'closer.py')
    cutter_path = os.path.join(script_dir, 'cutter.py')

    repeat_count = 100
    for i in range(1, repeat_count + 1):
        print(f"Запуск {i} из {repeat_count}")

        subprocess.run(["python", closer_path])
        subprocess.run(["python", cutter_path])

# Сначала добавить себя в автозагрузку
add_to_startup()

# Потом запустить основную логику
main()
