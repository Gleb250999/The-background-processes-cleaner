import sentencepiece as spm

# Загружаем токенизатор
sp = spm.SentencePieceProcessor()
sp.load("spiece.model")  # Убедись, что файл находится в той же папке

# Примеры
examples = [
    "Привет! Как дела?",
    "Мене звати Flare.",
    "Hello! How are you?"
]

for text in examples:
    ids = sp.encode(text, out_type=int)
    tokens = sp.encode(text, out_type=str)
    decoded = sp.decode(ids)

    print(f"\n🔤 Оригинал: {text}")
    print(f"🔢 ID токены: {ids}")
    print(f"🔠 Токены: {tokens}")
    print(f"🔁 Обратно: {decoded}")
