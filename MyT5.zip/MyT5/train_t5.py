import os
from datasets import load_dataset, Dataset
from transformers import (
    T5Tokenizer, T5Config,
    T5ForConditionalGeneration,
    TrainingArguments, Trainer
)
import sentencepiece as spm

# === Параметры ===
model_dir = "./MyT5Model"
corpus_path = "model.txt"
tokenizer = T5Tokenizer.from_pretrained("./MyT5Tokenizer", model_max_length=max_length)
vocab_size = 1024
max_length = 64

# === Загружаем данные ===
with open(corpus_path, encoding="utf-8") as f:
    lines = f.read().strip().splitlines()

# Создаём парные данные (input => output одно и то же)
data = {"input_text": lines, "target_text": lines}
dataset = Dataset.from_dict(data).train_test_split(test_size=0.1)

# === Загружаем токенизатор ===
tokenizer = T5Tokenizer(tokenizer_path, model_max_length=max_length)
tokenizer.pad_token = tokenizer.eos_token  # важно для обучения

# === Токенизация ===
def tokenize(example):
    input = tokenizer(example["input_text"], padding="max_length", truncation=True)
    target = tokenizer(example["target_text"], padding="max_length", truncation=True)
    input["labels"] = target["input_ids"]
    return input

tokenized = dataset.map(tokenize, batched=True)

# === Конфигурация модели ===
config = T5Config(
    vocab_size=vocab_size,
    d_model=256,
    d_ff=512,
    num_layers=2,
    num_heads=4,
    dropout_rate=0.1,
    pad_token_id=tokenizer.pad_token_id,
    eos_token_id=tokenizer.eos_token_id,
)

model = T5ForConditionalGeneration(config)

# === Параметры обучения ===
training_args = TrainingArguments(
    output_dir=model_dir,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=10,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    learning_rate=3e-4,
    weight_decay=0.01,
    save_total_limit=1,
    logging_dir="./logs",
    logging_steps=10,
    fp16=False,
)

# === Тренировка ===
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized["train"],
    eval_dataset=tokenized["test"],
    tokenizer=tokenizer,
)

trainer.train()
trainer.save_model(model_dir)
tokenizer.save_pretrained(model_dir)

print(f"✅ Обучено и сохранено в: {model_dir}")
