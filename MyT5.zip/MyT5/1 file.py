import sentencepiece as spm

model_path = r"C:\Users\Lenovo 1tb\Desktop\MyT5\spiece.model"  # укажи свой путь

sp = spm.SentencePieceProcessor()
sp.load(model_path)

print("Размер словаря:", sp.get_piece_size())
print("Первые 10 токенов:", [sp.id_to_piece(i) for i in range(10)])
