from transformers import T5ForConditionalGeneration

# Загружаем предобученную модель
model = T5ForConditionalGeneration.from_pretrained("t5-small")

# Сохраняем модель как pytorch_model.bin
model.save_pretrained("./MYT5")
