import sentencepiece as spm

spm.SentencePieceTrainer.train(
    input="C:/Users/Lenovo 1tb/Desktop/MyT5/corpus.txt",
    model_prefix="C:/Users/Lenovo 1tb/Desktop/MyT5/multilang_trilingual",
    vocab_size=300  # или даже 200
)

print("✅ Обучение завершено. Модель и словарь сохранены.")
